# fruit-tools-game data

# The data

Full property vectors for fruits and tools are in fruits_properties.npy and tools_properties.npy respectively. Each row correspond to a fruit (resp. tool), ordered as in fruits_names.npy (resp. tools_names.npy), each column is a feature.

The features are ordered as in the mapping matrices: these matrices are shown in the original paper's supplementary material, or in the tabs in the Excel file 'McRae_analysis_Jan31.xlsx' (M is in the tab ``Tool Fruit Mat``, M_fruit is in the tab ``Fruit features properties``, M_tool is in the tab ``Tool features properties``). That is, for example the tool features are ordered as:

has_a_handle
is_sharp
has_a_blade
has_a_head
is_small
has_a_sheath
has_prongs
is_loud
is_serrated
has_handles
has_blades
has_a_round_end
is_adorned_with_feathers
is_heavy
has_jaws
